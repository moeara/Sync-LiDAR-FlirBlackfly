import socket
import time
import pynmea2

import rclpy

Address = ''
Port = 8308

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

sock.bind((Address, Port))

while True:
        data = sock.recv(512)               #read data from port
        nmea_data = data[206:278].decode()) #extract the position and time message
        msg = pynmea2.parse(nmea_data)      #parse data into time, latitude and longitude data
        
        #Publish data on a ros topic

sock.close()
